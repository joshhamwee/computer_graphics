#include <glm/glm.hpp>
#include <iostream>

class RayTriangleIntersection
{
  public:
    glm::vec3 intersectionPoint;
    float distanceFromCamera;
    float distanceFromLight;
    ModelTriangle intersectedTriangle;
    int triangleIndex;

    RayTriangleIntersection()
    {
    }

    RayTriangleIntersection(glm::vec3 point, float distance, float distanceLight, ModelTriangle triangle, int index)
    {
        intersectionPoint = point;
        distanceFromCamera = distance;
        distanceFromLight = distanceLight;
        intersectedTriangle = triangle;
        triangleIndex = index;
    }
};

std::ostream& operator<<(std::ostream& os, const RayTriangleIntersection& intersection)
{
    // os << "Intersection is at " << intersection.intersectionPoint << " on triangle " << intersection.intersectedTriangle << " at a distance of " << intersection.distanceFromCamera << std::endl;
    return os;
}
